import java.io.IOException;
import java.net.*;
import java.io.*;
import java.util.*;

/**
 * Represents a publisher.
 */
public class Publisher implements Runnable {
    private Socket socket;
    private ObjectOutputStream outputStream;
    private Scanner input;
    private List<String> topics;
    private String name; //pub1, pub2, etc.


    /**
     * Instantiates a {@link Publisher} with the provided parameters.
     * @param brokerIPAddress - the broker's IP address.
     * @param brokerPortNumber - the broker's port number.
     * @param name the name of this publisher.
     * @param topics - the topics that the publisher will publish on.
     */
    public Publisher(String brokerIPAddress,
                     int brokerPortNumber,
                     String name,
                     List<String> topics)
    {
        setName(name);
        setTopics(topics);
        try {
            socket = new Socket(brokerIPAddress, brokerPortNumber);
            outputStream = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            //***
            input = new Scanner(System.in);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(name == null) {
            throw new IllegalArgumentException("Publisher name cannot be null");
        }
        this.name = name;
    }

    public List<String> getTopics() {
        return new ArrayList<>(topics);
    }

    public void setTopics(List<String> topics) {
        if(topics == null || topics.isEmpty()) {
            throw new IllegalArgumentException("A publisher must have at least one topic");
            //Publisher en az 1 topic içermeli.
        }
        this.topics = topics;
    }

    /**
     * Publishes a message.
     * @param message - the message to publish.
     */
    public void publishMessage(Message message) {
        if(!isValidMessage(message)) {
            throw new RuntimeException("Invalid message. Ensure that the message has a topic and a body.");
        }
        try {
            outputStream.writeObject(message);
            outputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Checks a message for validity.
    private boolean isValidMessage(Message message) {
        return message.getTopic() != null && !message.getTopic().isBlank()
                && message.getBody() != null && !message.getBody().isBlank();
    }

    @Override
    public void run() {
        while(socket.isConnected()) {
            try {
                System.out.format("***********WELCOME TO PUBLISHER %s***********\n", getName());
                System.out.println("What would you like to do?");
                System.out.println("1. Publish\n2. Exit");
                String line = input.nextLine();
                if(line.equals("1")) {
                    System.out.println("Enter message topic: ");
                    line = input.nextLine();
                    Message message = new Message();
                    message.setTopic(line);
                    System.out.println("Enter message body: ");
                    line = input.nextLine();
                    message.setBody(line);
                    message.setSender(getName());
                    publishMessage(message);
                }
                else {
                    System.out.format("Publisher %s disconnected.", getName());
                    input.close();
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        String[] socket = args[0].split(":");
        List<String> topics = new ArrayList<>(Arrays.asList(args[2].split(";")));
        new Thread(new Publisher(socket[0], Integer.parseInt(socket[1]), args[1], topics)).start();
    }
}
