import java.io.Serializable;

/**
 * Represents a message.
 */
public class Message implements Serializable {
    private String topic;
    private String body;
    private String sender;

    /**
     * Instantiates a {@link Message}.
     */
    public Message() {
    }

    /**
     * Instantiates a {@link Message} with the provided arguments.
     * @param topic - the topic of the message.
     * @param body - the body of the message.
     * @param sender - the sender of the message.
     */
    public Message(String topic, String body, String sender) {
        setTopic(topic);
        setBody(body);
        setSender(sender);
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        if(topic == null || topic.isBlank()) {
            throw new IllegalArgumentException("Message topic cannot be null or blank.");
        }
        this.topic = topic;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        if(body == null || body.isBlank()) {
            throw new IllegalArgumentException("Message body cannot be null or blank.");
        }
        this.body = body;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        if(body == null || body.isBlank()) {
            throw new IllegalArgumentException("Message sender cannot be null or blank.");
        }
        this.sender = sender;
    }

    @Override
    public String toString() {
        return String.format("Topic: %s\nBody: %s", getTopic(), getBody());
    }
}
