import java.net.*;
import java.io.*;
import java.util.*;

/**
 * Represents a subscriber.
 */
public class Subscriber implements Runnable {
    private Socket socket;
    private ObjectInputStream inputStream;
    private List<String> topics;
    private String name; //sub1, sub2, etc.

    /**
     * Instantiates a {@link Subscriber}.
     * @param ipAddress - the IP address of the broker.
     * @param port - the port number of the broker.
     * @param name - the subscriber's name.
     * @param topics - the list of topics that this subscriber listens to.
     */
    public Subscriber(String ipAddress, int port, String name, List<String> topics) {
        try {
            socket = new Socket(ipAddress, port);
            inputStream = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
            this.topics = topics;
            this.name = name;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getName() {
        return name;
    }

    /**
     * Writes a message to the console.
     * @param message - the message to write to the console.
     */
    public synchronized void writeMessageToConsole(Message message) {
        if(topics.contains(message.getTopic())) {
            System.out.format("Subscriber %s writing message: \n", getName());
            System.out.println(message);
        }
    }

    @Override
    public void run() {
        System.out.format("Subscriber %s listening for messages...", getName());
        System.out.println();
        while(socket.isConnected()) {
            try {
                Message message = (Message) inputStream.readObject();
                writeMessageToConsole(message);
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        System.out.format("Subscriber %s disconnected.", getName());
    }

    public static void main(String[] args) {
        String[] socket = args[0].split(":");
        List<String> topics = new ArrayList<>(Arrays.asList(args[2].split(";")));
        new Thread(new Subscriber(socket[0], Integer.parseInt(socket[1]), args[1], topics)).start();
    }
}
