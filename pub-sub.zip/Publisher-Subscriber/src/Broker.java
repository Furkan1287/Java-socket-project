import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Models a broker.
 */
public class Broker implements Runnable {
    private ServerSocket  publisherServerSocket;
    private ServerSocket  subscriberServerSocket;
    public static final int PUBLISHER_PORT = 5002;
    public static final int SUBSCRIBER_PORT = 5003;
    public final Set<ObjectOutputStream> SUBSCRIBER_OUTPUT_STREAMS = new HashSet<>();
    public final Map<Socket, ObjectOutputStream> SUBSCRIBER_SOCKETS = new HashMap<>();
    private int numberOfActivePublishers;
    private int numberOfActiveSubscribers;

    /**
     * Instantiates a {@link Broker}.
     */
    public Broker() {
        try {
            publisherServerSocket = new ServerSocket(PUBLISHER_PORT);
            subscriberServerSocket = new ServerSocket(SUBSCRIBER_PORT);
            numberOfActivePublishers = 0;
            numberOfActiveSubscribers = 0;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        System.out.println("Broker running on 127.0.0.1...");
        System.out.println("Publisher port: " + PUBLISHER_PORT);
        System.out.println("Subscriber port: " + SUBSCRIBER_PORT);
        new PublisherHandler(publisherServerSocket).start();
        new SubscriberHandler(subscriberServerSocket).start();
    }

    public void displayStatus() {
        System.out.println("Number of active subscribers: " + numberOfActiveSubscribers);
        System.out.println("Number of active publishers: " + numberOfActivePublishers);
    }

    public static void main(String[] args) {
        new Thread(new Broker()).start();
    }

    private class PublisherHandler extends Thread {

        private final ServerSocket serverSocket;

        public PublisherHandler(ServerSocket socket) {
            this.serverSocket = socket;
        }

        @Override
        public void run() {
            try {
                while (true) {
                    Socket socket = serverSocket.accept();
                    numberOfActivePublishers++;
                    System.out.println("A new publisher has joined.");
                    displayStatus();
                    new Publisher(socket).start();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private class Publisher extends Thread {
            private final Socket socket;

            private Publisher(Socket socket) {
                this.socket = socket;
            }

            @Override
            public void run() {
                try {
                    ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                    while (socket.isConnected()) {
                        Message message = (Message) inputStream.readUnshared();
                        System.out.println("Publisher "  + message.getSender() + " sent a message.");
                        SUBSCRIBER_SOCKETS.entrySet().forEach(entry -> {
                            if(entry.getKey().isConnected()) {
                                try {
                                    //SUBSCRIBERS_SOCKETS is a map to keep keys and values
                                    //Key: value
                                    //Socket: Object Output stream
                                    entry.getValue().writeObject(message);
                                    entry.getValue().flush();
                                } catch (IOException e) {
                                    // When a subscriber disconnects abruptly (i.e by closing the subscriber program without invoking socket.close())
                                    // a SocketException would be thrown. In this case we should remove this publisher's socket from the sockets map
                                    // and decrement the number of subscribers by one.
                                    //Subscriberın bağlantısı eğer zamansızca kesilirse (subscriber programı socket.close() 'U uyandırmadan kapanırsa)
                                    //socketexception atılıyor ve bu durumda, bu publisherın soketi, socket mapten kaldırılıyor-
                                    //subscriber sayısını 1 azaltarak.
                                    SUBSCRIBER_SOCKETS.remove(socket);
                                    numberOfActiveSubscribers--;
                                    System.out.println("A subscriber has disconnected.");
                                    displayStatus();
                                }
                            }
                        });
                    }
                    numberOfActivePublishers--;
                } catch (IOException | ClassNotFoundException e) {
                    // When publisher disconnects abruptly (i.e by closing the publisher program without invoking socket.close())
                    // a SocketException would be thrown. In this case we should check if this publisher socket is still
                    // connected. If it is we should close it and decrement the number of publishers by one.
                   if(socket.isConnected()) {
                       try {
                           socket.close();
                           numberOfActivePublishers--;
                           System.out.println("A publisher has disconnected.");
                           displayStatus();
                       } catch (IOException ex) {
                           ex.printStackTrace();
                       }
                   }
                }
            }
        }
    }

    private class SubscriberHandler extends Thread {
        private final ServerSocket serverSocket;

        public SubscriberHandler(ServerSocket serverSocket) {
            this.serverSocket = serverSocket;
        }
        //Subscriber handler'ın server socketini set ediyor.
        @Override
        public void run() {
            try {
                while (true) {
                    Socket socket = serverSocket.accept();
                    numberOfActiveSubscribers++;
                    System.out.println("A new subscriber has joined.");
                    displayStatus();
                    new Subscriber(socket).start();
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }

        private class Subscriber extends Thread {
            private final Socket socket;

            public Subscriber(Socket socket) {
                this.socket = socket;
            }

            @Override
            public void run() {
                try {

                    //Socket
                    //Output stream - send messages to broker --> publisher
                    //Input stream receive messages from broker

                    ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                    //Önce raw olarak outputstream'i alıyor.-socket.getoutputstream
                    //new object... da raw output streami karaktere dönüştürüyor.
                    //objectutputStream outputStream de de objeye dönüştürüyor.

                    SUBSCRIBER_SOCKETS.put(socket, outputStream);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
